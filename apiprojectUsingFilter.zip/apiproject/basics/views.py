from django.shortcuts import render
from rest_framework import generics
from basics.models import Student
from basics.serializers import StudentSerializer
# Create your views here.


class StudentList(generics.ListCreateAPIView):
    queryset=Student.objects.all()
    serializer_class=StudentSerializer
class StudentDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset=Student
    serializer_class=StudentSerializer



class GetItemFromStudentView(generics.ListAPIView):
    serializer_class = StudentSerializer
    
    def get_queryset(self):
        name=self.kwargs['name']
        queryset = Student.objects.filter(name__iexact=name)
        return queryset    